

<DOCTYPE html>
<html>
<head>
	
	<link rel="stylesheet" href="styles.css">

</head>
	<body>
	<h2><img src="img/marketlogo.png" class ="center"></h2>
		<ul>
  <li><a href="HomePage.php">Home</a></li>
  <li><a href="profile.php">Profile</a></li>
  <li><a href="contactus.php">Contact</a></li>
  <li><a href="myitems.php">My items</a></li>
   <li><a href="orderhistory.php">Order History</a></li>
  
  
</ul>

<!DOCTYPE html>
<?php
	session_start();

	$user='root';
	$pass='';
	$db='cis330_final';
	
	$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>
	
<html>
<head>
	<link rel="stylesheet" href="styles.css">
</head>

	<body>
	
	<form action="HomePage.php" method="GET">
		<input type="text" placeholder="Search.." name="name_search" value="" class = "center">
		<select name="State" class = "center">
			<option value ="any">Any States</option>
			<option value ="AL">Alabama</option>
			<option value ="AK">Alaska</option>
			<option value ="AZ">Arizona</option>
			<option value ="AR">Arkansas</option>
			<option value ="CA">California</option>
			<option value ="CO">Colorado</option>
			<option value ="CT">Connecticut</option>
			<option value ="DE">Delaware</option>
			<option value ="FL">Florida</option>
			<option value ="GA">Georgia</option>
			<option value ="HI">Hawaii</option>
			<option value ="ID">Idaho</option>
			<option value ="IL">Illinois</option>
			<option value ="IN">Indiana</option>
			<option value ="IA">Iowa</option>
			<option value ="KS">Kansas</option>
			<option value ="KY">Kentucky</option>
			<option value ="LA">Louisiana</option>
			<option value ="ME">Maine</option>
			<option value ="MD">Maryland</option>
			<option value ="MA">Massachusetts</option>
			<option value ="MI">Michigan</option>
			<option value ="MN">Minnesota</option>
			<option value ="MS">Mississippi</option>
			<option value ="MO">Missouri</option>
			<option value ="MT">Montana</option>
			<option value ="NE">Nebraska</option>
			<option value ="NV">Nevada</option>
			<option value ="NH">New Hampshire</option>
			<option value ="NJ">New Jersey</option>
			<option value ="NM">New Mexico</option>
			<option value ="NY">New York</option>
			<option value ="NC">North Carolina</option>
			<option value ="ND">North Dakota</option>
			<option value ="OH">Ohio</option>
			<option value ="OK">Oklahoma</option>
			<option value ="OR">Oregon</option>
			<option value ="PA">Pennsylvania</option>
			<option value ="RI">Rhode Island</option>
			<option value ="SC">South Carolina</option>
			<option value ="SD">South Dakota</option>
			<option value ="TN">Tennessee</option>
			<option value ="TX">Texas</option>
			<option value ="UT">Utah</option>
			<option value ="VT">Vermont</option>
			<option value ="VA">Virginia</option>
			<option value ="WA">Washington</option>
			<option value ="WV">West Virginia</option>
			<option value ="WI">Wisconsin</option>
			<option value ="WY">Wyoming</option>
			<option value ="other">Other</option>
		</select>
		<select name="Category" class = "center">
			<option value ="any">Any Categories</option>
			<option value ="clothes">Clothes</option>
			<option value ="furniture">Furniture</option>
			<option value ="electronics">Electronics</option>
			<option value ="toys">Toys</option>
			<option value ="stationary">Stationary</option>
			<option value ="other">Other</option>
		</select>
		<input type="submit" name="search" class = "center"> </input>
    </form>

	<?php
		//General sql command, choosing without any filters
		$gen_sql="SELECT item.itemID,item_name,price,category,selling_date,name,state FROM item,sell,users WHERE item.itemID=sell.itemID AND users.userID=sell.userID AND item.sold=0";
		$sql=$gen_sql;
		//SQL command search by name
		if (isset($_GET["name_search"]) && $_GET["name_search"]!=""){
			$name_sql=" AND item_name LIKE \"%{$_GET["name_search"]}%\"";
			$sql=$sql.$name_sql;
		}
		//SQL command search by state
		if (isset($_GET["State"]) && $_GET["State"]!="any"){
			$state_sql=" AND users.userID in (SELECT userID from users WHERE users.state=\"{$_GET["State"]}\")";
			$sql=$sql.$state_sql;
		}
		
		
		//SQL command search by category
		if (isset($_GET["Category"])&& $_GET["Category"]!="any"){
			$category_sql=" AND item.category=\"{$_GET["Category"]}\"";
			$sql=$sql.$category_sql;
		}
		
		
		
		//echo $sql;
		$result = $db->query($sql);
		
		if ($result->num_rows > 0) {
			echo "<table><tr><th>Item Name</th><th>Price</th><th>Category</th><th>Selling date</th><th>Seller</th><th>State</th><th>Buy Now</th></tr>";
			// output data of each row
			while($row = $result->fetch_assoc()) {
				echo "<tr><td>". $row["item_name"]. "</td><td>". $row["price"]. "</td><td>" . $row["category"] ."</td><td>" . $row["selling_date"] ."</td><td>" . $row["name"] ."</td><td>" . $row["state"] ."</td><td>" . 
					"<form action=\"payment.php\" method=\"post\">"."<button type=\"submit\" name = \"buyItem\" value=\"{$row["itemID"]}\"> Buy</button></form><br>" . "</td></tr>";
				//echo "<form action=\"payment.php\" method=\"post\">"."<button type=\"submit\" name = \"buyItem\" value=\"{$row["itemID"]}\"> {$row["item_name"]} </button></form><br>";
			}
			echo "</table>";
		} else {
			echo "No results found.";
		}
		
		

		$db->close();

	?>
	
	
	<form action="/final/marketplace.php">
		<input type="submit" value="Logout" class = "center3">
	</form> 


</body>

</html>

	<br>
</body>

</html>