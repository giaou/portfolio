<?php
	session_start();
	
	$options=$_POST["method"];
	$cardNumber=$_POST["cardnumber"];
	
	$user='root';
	$pass='';
	$db='cis330_final';
	
	$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>


<?php
	$sql = "INSERT INTO payment(userID,options,cardNumber) VALUES(\"{$_SESSION["userID"]}\",\"{$options}\",\"{$cardNumber}\")";		
	echo $sql;
	if ($db->query($sql) === TRUE) {
		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $db->error;
	}
	header("location:HomePage.php");
?>