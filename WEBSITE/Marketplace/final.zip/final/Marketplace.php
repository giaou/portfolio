

<DOCTYPE html>
<html>
<head>

	<link rel="stylesheet" href="styles.css">
	
	<h2><img src="img/marketlogo.png" class ="center1"></h2>
</head>

	<body>



<form action="login.php">
  <input type="submit" value="Login" class = "center2">
</form>
<form action="signup.php">
  <input type="submit" value="Sign Up" class= "center2">
</form>

</body>

</html>