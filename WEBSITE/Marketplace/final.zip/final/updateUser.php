<!DOCTYPE html>

<?php
	session_start();
	
	$user='root';
	$pass='';
	$db='cis330_final';
	
	$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>

<html>
 <body>


<?php
	$sql = "SELECT * FROM users WHERE userID={$_SESSION["userID"]}";
	$result = mysqli_query($db, $sql);


	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {				
				echo "<form action=\"/final/updateUserAction.php\" method=\"post\">\n";
	echo "  Name: <br /> \n";
	echo "  <input name=\"fullname\" type=\"text\" value=\"{$row["name"]}\"/><br /> \n";
	echo "  Password: <br /> \n";
	echo "  <input name=\"pwd\" type=\"password\" value=\"{$row["passwords"]}\"/><br /> \n";
	echo "  Address: <br /> <input name=\"address\" type=\"text\" value=\"{$row["address"]}\"/><br />\n";
	echo "  Age: <br />\n";
	echo "  <input name=\"age\" type=\"number\" value=\"{$row["age"]}\"/><br /> \n";
	echo "  Gender: <br />\n";
	echo "  <select name=\"gender\">\n";
	echo "	<option value =\"male\">Male</option>\n";
	echo "	<option value =\"female\">Female</option>\n";
	echo "	<option value =\"other\">Other</option>\n";
	echo "  </select> <br />\n";
	echo "  \n";
	echo "  Email: <br /> <input name=\"email\" type=\"email\" value=\"{$row["email"]}\"/><br /> \n";
	echo "  State: <br /> <select name=\"state\">\n";
	echo "			<option value =\"AL\">Alabama</option>\n";
	echo "			<option value =\"AK\">Alaska</option>\n";
	echo "			<option value =\"AZ\">Arizona</option>\n";
	echo "			<option value =\"AR\">Arkansas</option>\n";
	echo "			<option value =\"CA\">California</option>\n";
	echo "			<option value =\"CO\">Colorado</option>\n";
	echo "			<option value =\"CT\">Connecticut</option>\n";
	echo "			<option value =\"DE\">Delaware</option>\n";
	echo "			<option value =\"FL\">Florida</option>\n";
	echo "			<option value =\"GA\">Georgia</option>\n";
	echo "			<option value =\"HI\">Hawaii</option>\n";
	echo "			<option value =\"ID\">Idaho</option>\n";
	echo "			<option value =\"IL\">Illinois</option>\n";
	echo "			<option value =\"IN\">Indiana</option>\n";
	echo "			<option value =\"IA\">Iowa</option>\n";
	echo "			<option value =\"KS\">Kansas</option>\n";
	echo "			<option value =\"KY\">Kentucky</option>\n";
	echo "			<option value =\"LA\">Louisiana</option>\n";
	echo "			<option value =\"ME\">Maine</option>\n";
	echo "			<option value =\"MD\">Maryland</option>\n";
	echo "			<option value =\"MA\">Massachusetts</option>\n";
	echo "			<option value =\"MI\">Michigan</option>\n";
	echo "			<option value =\"MN\">Minnesota</option>\n";
	echo "			<option value =\"MS\">Mississippi</option>\n";
	echo "			<option value =\"MO\">Missouri</option>\n";
	echo "			<option value =\"MT\">Montana</option>\n";
	echo "			<option value =\"NE\">Nebraska</option>\n";
	echo "			<option value =\"NV\">Nevada</option>\n";
	echo "			<option value =\"NH\">New Hampshire</option>\n";
	echo "			<option value =\"NJ\">New Jersey</option>\n";
	echo "			<option value =\"NM\">New Mexico</option>\n";
	echo "			<option value =\"NY\">New York</option>\n";
	echo "			<option value =\"NC\">North Carolina</option>\n";
	echo "			<option value =\"ND\">North Dakota</option>\n";
	echo "			<option value =\"OH\">Ohio</option>\n";
	echo "			<option value =\"OK\">Oklahoma</option>\n";
	echo "			<option value =\"OR\">Oregon</option>\n";
	echo "			<option value =\"PA\">Pennsylvania</option>\n";
	echo "			<option value =\"RI\">Rhode Island</option>\n";
	echo "			<option value =\"SC\">South Carolina</option>\n";
	echo "			<option value =\"SD\">South Dakota</option>\n";
	echo "			<option value =\"TN\">Tennessee</option>\n";
	echo "			<option value =\"TX\">Texas</option>\n";
	echo "			<option value =\"UT\">Utah</option>\n";
	echo "			<option value =\"VT\">Vermont</option>\n";
	echo "			<option value =\"VA\">Virginia</option>\n";
	echo "			<option value =\"WA\">Washington</option>\n";
	echo "			<option value =\"WV\">West Virginia</option>\n";
	echo "			<option value =\"WI\">Wisconsin</option>\n";
	echo "			<option value =\"WY\">Wyoming</option>\n";
	echo "			<option value =\"other\">Other</option>\n";
	echo "		</select><br>\n";
	echo "  <input type=\"submit\">\n";
	echo "  \n";
	echo "</form>";
		}
	} else {
		echo "Can't find item";
	}	  


	

?>


</body>
</html>