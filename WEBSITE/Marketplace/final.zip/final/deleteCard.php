<?php 
		$paymentID=$_POST["paymentID"];
		
		$user='root';
		$pass='';
		$db='cis330_final';
		
		$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>
<?php	
		
		$sql = "DELETE FROM payment WHERE paymentID={$paymentID}";
			
		echo $sql;
		if ($db->query($sql) === TRUE) {
			echo "Deleted record successfully";
		} else {
			echo "Error: " . $sql . "<br>" . $db->error;
		}
		header("location:HomePage.php");
						
?>
