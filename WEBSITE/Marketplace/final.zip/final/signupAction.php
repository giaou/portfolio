<?php
	session_start();
	
	$email=$_POST["email"];
	$password=$_POST["pwd"];
	$name=$_POST["fullname"];
	$address=$_POST["address"];
	$age=$_POST["age"];
	$gender=$_POST["gender"];
	$state=$_POST["state"];
	
	$user='root';
	$pass='';
	$db='cis330_final';
	
	$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>

<?php
	$sql = "INSERT INTO users(email,passwords,name,address,age,gender,state) VALUES(\"{$email}\",\"{$password}\",\"{$name}\",\"{$address}\",{$age},\"{$gender}\",\"{$state}\")";		
	echo $sql;
	if ($db->query($sql) === TRUE) {
		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $db->error;
	}
	header("location:login.php");
?>