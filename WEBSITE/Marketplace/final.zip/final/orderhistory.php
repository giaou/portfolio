

<DOCTYPE html>

<?php 
		session_start();
		$user='root';
		$pass='';
		$db='cis330_final';
		
		$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>
<html>
<head>
	<link rel="stylesheet" href="styles.css">
<h2><img src="img/marketlogo.png" class ="center"></h2>
	
</head>

	<body>
			<ul>
  <li><a href="HomePage.php">Home</a></li>
  <li><a href="profile.php">Profile</a></li>
  <li><a href="contactus.php">Contact</a></li>
  <li><a href="myitems.php">My items</a></li>
  <li><a href="orderhistory.php">Order History</a></li>
  <br>
  
  
  
</ul>
		
	<?php
		//General sql command, choosing without any filters
		
		$sql="SELECT purchasing_date,item_name,price,cardNumber FROM transactions,item,payment WHERE transactions.userID={$_SESSION["userID"]} AND transactions.itemID=item.itemID AND payment.paymentID=transactions.paymentID ORDER BY purchasing_date DESC";
		$result = $db->query($sql);
		
		if ($result->num_rows > 0) {
			echo "<table><tr><th>Buy History</th></tr>";
			// output data of each row
			while($row = $result->fetch_assoc()) {
				echo "<tr><td>". $row["purchasing_date"]. ": You bought ". $row["item_name"]. " with $" . $row["price"] ." using card ending with " . substr($row["cardNumber"],-4) ."</td></tr>";
			}
			echo "</table>";
		} else {
			echo "You have not buy any item yet.";
		}
		
		$sql="SELECT users.name buyer,purchasing_date,sell_item.item_name,price 
			FROM transactions,(SELECT item.item_name,item.itemID,item.price FROM item,sell,users WHERE item.itemID=sell.itemID AND users.userID=sell.userID AND item.sold=1 and users.userID={$_SESSION["userID"]}) sell_item,users
			WHERE transactions.itemID=sell_item.itemID AND users.userID=transactions.userID
			ORDER BY purchasing_date DESC";
		
		$result = $db->query($sql);
		
		if ($result->num_rows > 0) {
			echo "<table><tr><th>Sell History</th></tr>";
			// output data of each row
			while($row = $result->fetch_assoc()) {
				echo "<tr><td>". $row["purchasing_date"]. ": You sold ". $row["item_name"]. " to " . $row["buyer"] .". You gained $" . $row["price"] .".</td></tr>";
			}
			echo "</table>";
		} else {
			echo "You have not sold any item yet.";
		}
		
		
		

		$db->close();

	?>
</body>

</html>