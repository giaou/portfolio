<?php
	session_start();
	
	$itemname=$_POST["itemname"];
	$price=$_POST["price"];
	$category=$_POST["category"];
	
	
	$user='root';
	$pass='';
	$db='cis330_final';
	
	$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>

<?php
	$sqlInsert = "INSERT INTO item (item_name,price,category) VALUES(\"{$itemname}\",{$price},\"{$category}\")";
		
	echo $sqlInsert;
	
	if ($db->query($sqlInsert) === TRUE) {
		echo "New record created successfully";
		$last_id = $db->insert_id;
		date_default_timezone_set('America/Chicago');
		$date = date('Y-m-d H:i:s', time());
		$sqlSell ="INSERT INTO sell(userID,itemID,selling_date) VALUES ({$_SESSION["userID"]},{$last_id},\"{$date}\")";
		if ($db->query($sqlSell) === TRUE) {
		echo "New record created successfully";
		} else {
			echo "Error: " . $sqlSell . "<br>" . $db->error;
		}
	} else {
		echo "Error: " . $sqlInsert . "<br>" . $db->error;
	}
	
	header("location:myitems.php");
?>