<?php 
		$itemID=$_POST["itemID"];
		
		$user='root';
		$pass='';
		$db='cis330_final';
		
		$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>
<?php	
		
		$sql = "DELETE FROM item WHERE item.itemID={$itemID}";
			
		echo $sql;
		if ($db->query($sql) === TRUE) {
			echo "Deleted record successfully";
		} else {
			echo "Error: " . $sql . "<br>" . $db->error;
		}
		header("location:myitems.php");
						
?>
