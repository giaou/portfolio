

<!DOCTYPE html>

<?php 
		session_start();
		$user='root';
		$pass='';
		$db='cis330_final';
		
		$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>
<html>
<head>

	<link rel="stylesheet" href="styles.css">

	
</head>

	<body>
			<ul>
  <li><a href="HomePage.php">Home</a></li>
  <li><a href="profile.php">Profile</a></li>
  <li><a href="contactus.php">Contact</a></li>
  <li><a href="myitems.php">My items</a></li>
   <li><a href="orderhistory.php">Order History</a></li>
  
  
</ul> 	
	<br>

	<form action="addcard.php" method="post">
		<input type="submit" value = "Add Card">
	</form>
  
  <?php

		echo "<form action=\"buyItemAction.php\" method=\"post\">\n";
		echo "	<input type=\"hidden\" name=\"itemID\" value=\"{$_POST["buyItem"]}\">\n";
		echo "	<input type=\"submit\" value = \"Buy Item\">\n";
		echo "  </form>";

	?>
  
  
	
<?php
$sql =  "SELECT * from payment WHERE payment.userID={$_SESSION["userID"]}";
$result = $db->query($sql);
if ($result->num_rows > 0) {
			echo "<table><tr><th>Card Type</th><th>Card Number</th><th></th></tr>";
			// output data of each row
			while($row = $result->fetch_assoc()) {
				echo "<tr><td>". $row["options"]. "</td><td>" . $row["cardNumber"] ."</td><td>" .
				"<form action=\"buyItemAction.php\" method=\"post\">"."<button type=\"submit\" name = \"paymentID\" value=\"{$row["paymentID"]}\"> Buy </button>" . "</td></tr>";
				//echo "<form action=\"buyItemAction.php\" method=\"post\">"."<button type=\"submit\" name = \"paymentID\" value=\"{$row["paymentID"]}\"> Buy with {$row["cardNumber"]} </button>";
				echo "	<input type=\"hidden\" name=\"itemID\" value=\"{$_POST["buyItem"]}\">";
				echo "</form>";
			}
			echo "</table>";
		} else {
			echo "You do not have any card.";
		}	
?>
<?php	
		$sql = "SELECT item.itemID,item_name,price,category,selling_date,name,state FROM item,sell,users WHERE item.itemID=sell.itemID AND users.userID=sell.userID AND item.sold=0 AND item.itemID={$_POST["buyItem"]}";
		$result = mysqli_query($db, $sql);

		if ($result->num_rows > 0) {
			echo "<table><tr><th>Item Name</th><th>Price</th><th>Category</th><th>Selling date</th><th>Seller</th><th>State</th></tr>";
			// output data of each row
			while($row = $result->fetch_assoc()) {
				echo "<tr><td>". $row["item_name"]. "</td><td>". $row["price"]. "</td><td>" . $row["category"] ."</td><td>" . $row["selling_date"] ."</td><td>" . $row["name"] ."</td><td>" . $row["state"] . "</td></tr>";
			}
			echo "</table>";
		} else {
			echo "Can't find item";
		}
		
		
				
?>



</body>

</html>