<DOCTYPE html>

<?php
	session_start();

	$user='root';
	$pass='';
	$db='cis330_final';
	
	$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>
<html>
<head>

	<link rel="stylesheet" href="styles.css">
	
</head>

	<body>
	
	<h2><img src="img/marketlogo.png" class ="center"></h2>
		<ul>
  <li><a href="HomePage.php">Home</a></li>
  <li><a href="profile.php">Profile</a></li>
  <li><a href="contactus.php">Contact</a></li>
  <li><a href="myitems.php">My items</a></li>
   <li><a href="orderhistory.php">Order History</a></li>
  
  
</ul>
	<?php
		$sql="SELECT * FROM item,sell WHERE item.itemID=sell.itemID AND sell.userID=\"{$_SESSION["userID"]}\"";
		$result = $db->query($sql);
		
		if ($result->num_rows > 0) {
			echo "<table><tr><th>Item Name</th><th>Price</th><th>Category</th><th>Selling date</th><th></th><th></th></tr>";
			// output data of each row
			while($row = $result->fetch_assoc()) {
				echo "<tr><td>". $row["item_name"]. "</td><td> $". $row["price"]. "</td><td>" . $row["category"] ."</td><td>" . $row["selling_date"]."</td><td>" . 
					"<form action=\"updateItem.php\" method=\"post\">"."<button type=\"submit\" name = \"itemID\" value=\"{$row["itemID"]}\"> Update </button></form>"."</td><td>" . 
					"<form action=\"deleteItem.php\" method=\"post\">"."<button type=\"submit\" name = \"itemID\" value=\"{$row["itemID"]}\"> Delete </button></form><br>" . "</td></tr>";
				
			}
			echo "</table>";
		} else {
			echo "0 results";
		}
	?>
	<form action="additem.php">
		<input type="submit" value="Add New Item" class= "center2">
	</form>
	
	
</body>

</html>