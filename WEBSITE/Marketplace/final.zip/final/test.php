<?php
	$hash=password_hash("7891011", PASSWORD_DEFAULT);
	echo $hash."<br>";
?>