<!DOCTYPE html>
<html>
<body>
<?php
	if (isset($_GET["msg"]) && $_GET["msg"] == 'failed') {
		echo "Wrong Username / Password";
	session_start();
	
}
?>
<h2>Login Page</h2>

<form action="Login_Action.php" method="post">
  Email:<br>
  <input type="text" name="email">
  <br>
  Password:<br>
  <input type="password" name="password">
  <br><br>
  <input type="submit" value="Login">
</form> 

<form action="marketplace.php" method="post">
	<input type="submit" value="Back">
</form>

</body>
</html>
