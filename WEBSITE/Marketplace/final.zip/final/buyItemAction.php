<?php
		$itemID=$_POST["itemID"];
		$paymentID=$_POST["paymentID"];
		
		session_start();
		$user='root';
		$pass='';
		$db='cis330_final';
		
		$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>

<?php	
		
		$sqlUpdate = "UPDATE item SET item.sold=1 WHERE item.itemID={$itemID}";
			
		echo $sqlUpdate;
		if ($db->query($sqlUpdate) === TRUE) {
			echo "Updated item sold successfully.\n";
		} else {
			echo "Error: " . $sqlUpdate . "<br>" . $db->error;
		}
		
		
		date_default_timezone_set('America/Chicago');
		$date = date('Y-m-d H:i:s', time());
		
		$sqlInsert = "INSERT INTO transactions VALUES({$_SESSION["userID"]},{$itemID},\"{$date}\",{$paymentID});";
			
		echo $sqlInsert;
		if ($db->query($sqlInsert) === TRUE) {
			echo "Insert new transaction successfully.";
		} else {
			echo "Error: " . $sqlInsert . "<br>" . $db->error;
		}
		
		
		header("location:orderhistory.php");
							
?>
