<?php
	session_start();
	
	$item_name=$_POST["itemname"];
	$price=$_POST["price"];
	$category=$_POST["category"];
	$itemID=$_POST["itemID"];
	
	$user='root';
	$pass='';
	$db='cis330_final';
	
	$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>

<?php
	
	$sql = "UPDATE item SET item_name= \"{$item_name}\" , price={$price}, category=\"${category}\"  WHERE itemID={$itemID}";

	
	if ($db->query($sql) === TRUE) {
		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $db->error;
	}
	header("location:myitems.php");
?>