<?php 
		session_start();
		$email=$_POST["email"];
		$password=$_POST["password"];
		
		$user='root';
		$pass='';
		$db='cis330_final';
		
		$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>
<?php	
		$stmt = $db->prepare("SELECT userID,name FROM users WHERE email = ? AND passwords = ? LIMIT 1");
		$stmt->bind_param('ss', $email, $password);
		$stmt->execute();
		$stmt->bind_result($userID,$name);
		$stmt->store_result();
		if($stmt->num_rows == 1)  //To check if the row exists
		{
			if($stmt->fetch()) //fetching the contents of the row
			{
				$_SESSION["userID"] = $userID;
				header("location:HomePage.php");
			}
		}
		else {
			// remove all session variables
			session_unset();			
			// destroy the session
			session_destroy();
			header("location:login.php?msg=failed");
		}
		$stmt->close();
?>
