<!DOCTYPE html>

<?php
	session_start();
	
	$itemID=$_POST["itemID"];
	
	$user='root';
	$pass='';
	$db='cis330_final';
	
	$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>

<html>
 <body>

<?php
	$sql = "SELECT * FROM item WHERE itemID={$itemID}";
	$result = mysqli_query($db, $sql);

	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {				
			echo "<form action=\"/final/updateItemAction.php\" method=\"post\">";
				echo "<input type=\"hidden\" name=\"itemID\" value= \"{$itemID}\"/>";
				echo "Item Name: <br /> ";
				echo "<input name=\"itemname\" type=\"text\" value=\"{$row["item_name"]}\"/><br /> ";
				echo "Price: <br />";
				echo "<input name=\"price\" type=\"number\" step=\"0.01\" value=\"{$row["price"]}\"/><br /> ";
				echo "Category: ";
				echo "<select name=\"category\">";	
					echo "<option value=\"Furniture\"> Furniture</option>";
					echo "<option value=\"Electronics\"> Electronics</option>";
					echo "<option value=\"Toys\"> Toys</option>";
					echo "<option value=\"Clothes\"> Clothes</option>";
					echo "<option value=\"Stationery\"> Stationery</option>";
					echo "<option value=\"Other\"> Other</option>";
				echo "</select><br><br>";
				echo "<input type=\"submit\">";
			echo "</form>" ; 
		}
	} else {
		echo "Can't find item";
	}	  
	  
?>
</body>
</html>