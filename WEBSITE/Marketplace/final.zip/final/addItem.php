<!DOCTYPE html>
<html>
 <body>


<form action="/final/addItemAction.php" method="post">
  Item Name: <br /> 
  <input name="itemname" type="text" oninvalid="alert('You must insert the item's name');" required><br /> 
  Price: <br />
  <input name="price" type="number" step="0.01" value="1"><br /> 
  Category: 
  <select name="category">	  
	  <option value="Furniture"> Furniture</option>
	  <option value="Electronics"> Electronics</option>
	  <option value="Toys"> Toys</option>
	  <option value="Clothes"> Clothes</option>
	  <option value="Stationery"> Stationery</option>
	  <option value="Other"> Other</option>
  </select><br><br>
  
  
  
  
  
  <input type="submit">
  
</form>

</body>
</html>