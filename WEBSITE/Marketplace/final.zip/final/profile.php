<DOCTYPE html>
<?php 
		session_start();
		$user='root';
		$pass='';
		$db='cis330_final';
		
		$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>
<html>
<head>

	<link rel="stylesheet" href="styles.css">
	
</head>

	<body>
	
	<h2><img src="img/marketlogo.png" class ="center"></h2>
		<ul>
  <li><a href="HomePage.php">Home</a></li>
  <li><a href="profile.php">Profile</a></li>
  <li><a href="contactus.php">Contact</a></li>
  <li><a href="myitems.php">My items</a></li>
   <li><a href="orderhistory.php">Order History</a></li>
  
  
</ul>
	<form action="addcard.php" method="post">
		<input type="submit" value = "Add Card">
	</form>
	<?php
		$sql =  "SELECT * from payment WHERE payment.userID={$_SESSION["userID"]}";
		$result = $db->query($sql);
		if ($result->num_rows > 0) {
					echo "<table><tr><th>Card Type</th><th>Card Number</th><th></th><th></th></tr>";
					// output data of each row
					while($row = $result->fetch_assoc()) {
						echo "<tr><td>". $row["options"]. "</td><td>" . $row["cardNumber"] ."</td><td>" . 
							"<form action=\"deleteCard.php\" method=\"post\">"."<button type=\"submit\" name = \"paymentID\" value=\"{$row["paymentID"]}\"> Delete Card </button></form>" . "</td></tr>";
						
					}
					echo "</table>";
				} else {
					echo "You do not have any card.";
				}	
	?>
	<?php	
		$sql = "SELECT * FROM users WHERE userID={$_SESSION["userID"]}";
		$result = mysqli_query($db, $sql);

		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
				echo $row["userID"]. " ". $row["name"]. " " . $row["address"] ." " . $row["email"] ." " . $row["gender"] ." " . $row["age"] . " " . $row["state"];
			}
			
		} else {
			echo "Can't find user information";
		}
		
		
				
?>
	<br> <form action="updateUser.php">
		<button type="submit">Edit Profile</button>
	</form>

</body>

</html>