

<DOCTYPE html>

<?php 
		session_start();
		$user='root';
		$pass='';
		$db='cis330_final';
		
		$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>
<html>
<head>

	<link rel="stylesheet" href="styles.css">

	
</head>

	<body>
			<ul>
  <li><a href="HomePage.php">Home</a></li>
  <li><a href="profile.html">Profile</a></li>
  <li><a href="contactus.html">Contact</a></li>
  <li><a href="myitems.html">My items</a></li>
  <li><a href="orderhistory.php">Order History</a></li>
  
  
</ul>
		<p8>
		Please add your card information:
	</p8>
	<!DOCTYPE html>
<html>
 <body>

<form action="/final/insertCardAction.php" method="post">
  Method: <br /> 
  <select name="method">
	<option value ="credit"> Credit </option>
	<option value ="debit"> Debit </option>
  </select> <br/>

  Card number: <br /> 
  <input name="cardnumber" id ="chooseNum" type="text" pattern=".{12}" required><br><br>
  <input type="submit">
  
</form>


<script>
	document.getElementById("chooseNum").addEventListener("invalid", myFunction);

	function myFunction() {
	  alert("Please enter a valid card number length");
	}
</script>

</body>
</html>
	<br>
	<a href="payment.php">Confirm</a>

</body>

</html>