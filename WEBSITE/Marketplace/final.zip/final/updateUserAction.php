<?php
	session_start();
	
	$email=$_POST["email"];
	$password=$_POST["pwd"];
	$name=$_POST["fullname"];
	$address=$_POST["address"];
	$age=$_POST["age"];
	$gender=$_POST["gender"];
	$state=$_POST["state"];
	
	$user='root';
	$pass='';
	$db='cis330_final';
	
	$db= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect to database.");
?>

<?php
	
	$sql = "UPDATE users SET email= '{$email}' , passwords='{$password}', name='{$name}', address='{$address}', age={$age}, gender='{$gender}', state='{$state}' WHERE userID={$_SESSION["userID"]}";

	
	if ($db->query($sql) === TRUE) {
		echo "Record updated successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $db->error;
	}
	header("location:profile.php");
?>