

<DOCTYPE html>
<html>
<head>

	<link rel="stylesheet" href="styles.css">
	
</head>

	<body>
	
	<h2><img src="img/marketlogo.png" class ="center"></h2>
		<ul>
  <li><a href="HomePage.php">Home</a></li>
  <li><a href="profile.php">Profile</a></li>
  <li><a href="contactus.php">Contact</a></li>
  <li><a href="myitems.php">My items</a></li>
   <li><a href="orderhistory.php">Order History</a></li>
  
</ul>
	
	
	
	 <br>
	<img src="img/hartmann2.jpg" style = "float:left">
	<img src= "img/minh.jpg" style = "float:right" height = "400px" width = "400px">
	<img src="img/giao.png" style = "float:center" height = "400px" width = "400px">
	<br>
	

</body>

</html>

<!doctype html>
<html>


<style>

#popup{display:none; background:#efefef; border:1px solid black; width:10%; height:60px;}

</style>

<body>

<button onclick="document.getElementById('popup').style.display='block'"style = "float:center">Contact Us!</button>
<div id="popup">

hartmannj@fontbonne.edu
ug@fontbonne.edu
phanm@fontbonne.edu

<button onclick="document.getElementById('popup').style.display='none'" style = "float:center">Hide</button>

</div>

</body>
</html>
